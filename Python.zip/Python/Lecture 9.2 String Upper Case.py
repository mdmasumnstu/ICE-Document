#Lecture 9.2 python String Upper Case type data;
print("We use Number data type");

#String Upper Case type data number

first = "Hafizur"
last = "Rahman"

a= first.upper()

print(first)
print(a)