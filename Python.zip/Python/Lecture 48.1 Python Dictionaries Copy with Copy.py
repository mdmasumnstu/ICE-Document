# Lecture 48.1 Python Dictionaries Copy with Copy
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    }
    
print(info)


newInfo = info.copy()
print(newInfo)



