# Lecture 39.2 Python Update Set Item or Add Any Iterable
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

value.update(Num)
print(value)


