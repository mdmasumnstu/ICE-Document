# Lecture 40.4 Python Clear Set Item 
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

val = value.clear()
print(val)

data = Num.clear()
print(data)


