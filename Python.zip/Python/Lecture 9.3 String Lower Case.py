#Lecture 9.3 python String Lower Case type data;
print("We use Number data type");

#String Lower Case type data number

first = "HAFIZUR RAHMAN"
last = "Rahman"

a= first.lower()

print(first)
print(a)