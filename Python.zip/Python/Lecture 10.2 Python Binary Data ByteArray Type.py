#Lecture 10.2 Python Binary Data Type;
print("We use Python Code");

numlist = [23,45,4,3,7,76]
a= bytearray(numlist)
a[4]= 122
print(a)


print(type(a))

