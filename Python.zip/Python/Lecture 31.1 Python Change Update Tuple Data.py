# Lecture 31.1 Python Change/Update Tuple Data 
print("We use Python Code")

value = ("Dhaka","Sylhet",True, "Chattogram","Rangpur",24,56,False)

listvalue = list(value)
listvalue[1] = "Sherpur"

value = tuple(listvalue)
print(listvalue)
print(type(listvalue))

print(value)
print(type(value))
