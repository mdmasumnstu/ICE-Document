# Lecture 12.1 Python Sequence Type Data
print("We use Python Code")

print("We can change the value of list in sequence")
value = ["Apple","Banana", "Cherry"]
print(value)

value[2]= "Orange"
print(value)
