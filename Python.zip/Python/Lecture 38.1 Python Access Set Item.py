# Lecture 38.1 Python Access Set Item
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
Num= (34,78,5,3,5,5,3)

for x in value:
    print(x)
    
for y in Num:
    print(y)