<!DOCTYPE html>
<html>
<body>

<?php
// Parent class
class Fruit {
  public $name;
  public $color;
  
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color; 
  }
  
  public function intro() {
    echo "The fruit is $this->name and the color is $this->color.<br>"; 
  }
}

// Strawberry is inherited from Fruit
class Strawberry extends Fruit {
  public function message() {
    echo "Am I a fruit or a berry? "; 
  }
}

$strawberry = new Strawberry("Strawberry", "red");
$strawberry->intro();
$strawberry->message();
?>
 
</body>
</html>
