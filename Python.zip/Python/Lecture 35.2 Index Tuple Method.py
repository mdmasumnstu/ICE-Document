# Lecture 35.2 Index Tuple Method
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
Num= (34,78,5,3,5,5,3)

print(value.index("India"))
print(Num.index(5))
