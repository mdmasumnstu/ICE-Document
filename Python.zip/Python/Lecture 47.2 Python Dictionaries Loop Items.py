# Lecture 47.2 Python Dictionaries Loop Items
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    }
    
print(info)

for x,y in info.items():
    print(x,y)

