# Lecture 22.1 Python For Loop
print("We use Python Code")

value = ["Dhaka","Rajshahi","Khulna","Sylhet"]
print(value)

for Prem in value:
    print(Prem)


for i in range(len(value)):
    print(i)


for i in range(21,34):
    print(i)

