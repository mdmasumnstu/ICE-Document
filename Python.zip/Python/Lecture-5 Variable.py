#lecture 5 python variable 
print("We use variable");

name= "Md Masum";
print(name);

#It seems that the semicolon use aren't mandatory
number= 5667678;
print(number);

fullname= "md masum";
print(fullname);
print("fullname");