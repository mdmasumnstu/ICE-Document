#Lecture 9.4 python String Remove Whitespace;
print("We use Number data type");

#String Remove Whitespace Before and After

first = " HAFIZUR RAHMAN"

a= first.strip()

print(first)
print(a)