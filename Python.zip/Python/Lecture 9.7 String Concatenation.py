#Lecture 9.7 python String Concatenation;
print("We use Number data type");

#String Concatenation

first = "Hafizur"
last = "Rahman"

fullname = first+last
withspace = first + ' ' + last

print(fullname)
print(withspace)

