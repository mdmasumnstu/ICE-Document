# Lecture 21.4 Python  Data Removes Delete
print("We use Python Code")

value = [23,54,56,34,29,75]
print(value)

del value[1]
print(value)

list = ["Dhaka","Chattogram","Sylhet","Khulna"]
print(list)

del list

print(list)


