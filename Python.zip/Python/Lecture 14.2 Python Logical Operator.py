# Lecture 14.2 Python Logical Operator
print("We use Python Code")

a= 12
b=32

print("A is Greater than B and B is less than 3: ",a>b and b<3)
print("A is Less than B and B is Greater than 3: ",a<b or a>6)
print("A is Greater than B and B is less than 3 NOT: ", (not(a>b and b<3)))