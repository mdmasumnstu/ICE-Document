# Lecture 43.2 Python Dictionaries Type()
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Department": "Information and Communication Engineering",
    }
    
print(info)

print(type(info))