#comment the line for one line use hash sign in line first
print("This is comment line lecture");
print("For comment use hash sign");


'''Thsi is  multiple line comment
and use three single quotation '''

print("We use comment sign in pyhon language programming");
print("Thank You");

