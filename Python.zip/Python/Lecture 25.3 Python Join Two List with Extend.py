# Lecture 25.3 Python Join Two List with Extend
print("We use Python Code")

value = [56,89,34,56,32,67]
print("The First Array List: ",value)

val = [34,65,33,57]
print("The Second Array List: ",val)

value.extend(val)
print("The Extended or Joining value: ",value)