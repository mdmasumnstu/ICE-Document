#lecture 8 python String type data;
print("We use Number data type");

#str type data number

firstname="Hafizur";
lastname= "Rahman";

print(firstname);
print(type(firstname));

print(lastname);
print(type(lastname));

print(firstname + ' ' + lastname);
print(type(firstname + lastname));
 
print('This is:' + ' ' +firstname);

print(firstname,lastname)
print(f"{firstname} {lastname}")