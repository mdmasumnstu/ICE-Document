# Lecture 24.2 Python Sort List Reverse
print("We use Python Code")

value = [56,89,34,56,32,67]
print(value)

value.sort(reverse=True)
print(value)


place = ["Dhaka","Khulna","Sylhet","Barishal"]
print(place)

place.sort(reverse = False)
print(place)

