# Lecture 13 Python Arithmatic Operator
print("We use Python Range Code")

num1 = 34
num2 = 3

sum= num1+num2
sub = num1-num2
multi = num1*num2
div = num1/num2
mud= num1%num2
exp =num1**num2
floor= num1//num2

print("Sum =", sum)
print("Subtraction =", sub)
print("Multiplication =", multi)
print("Division =", div)
print("Modulus =", mud)
print("Exponent =", exp)
print("Floor Division =", floor)