# Lecture 43.3 Python Dictionaries Length
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Department": "Information and Communication Engineering",
    }
    
print(info)

# print(type(info))

print(len(info))