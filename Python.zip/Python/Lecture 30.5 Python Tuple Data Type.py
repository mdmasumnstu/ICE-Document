# Lecture 30.5 Python Tuple Data Type  
print("We use Python Code")

value = ("Dhaka","Sylhet",True, "Chattogram","Rangpur",24,56,False,True,43,"Mymensingh",True)

print(type(value))

