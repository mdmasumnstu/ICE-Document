# Lecture 23 Python List Comprehension
print("We use Python Code")

value = [1,2,3,4,5,6]
print(value)

'''

for i in value:
    print("This is Index: ",i)
    print(value[i])

'''

print("The other value: ")


double = [i/4 for i in value]
print(double)

multi = [i**2 for i in value]
print(multi)
