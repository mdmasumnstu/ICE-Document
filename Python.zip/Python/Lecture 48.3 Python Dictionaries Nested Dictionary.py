# Lecture 48.3 Python Dictionaries Nested Dictionary
print("We use Python Code")

info= {
   "child1": {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"]
   },
   
   "child2":{
    "Name": "Abir",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"]
 },
 
 "child3":{
  "Name": "Rahat",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"]
    },
   }
    
print("The Info are: ",info)

for x,obj in info.items():
    print("the info: ",x)
    
    for y in obj:
       print(y + ':', obj[y])





