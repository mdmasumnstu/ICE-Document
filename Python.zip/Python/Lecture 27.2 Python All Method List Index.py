# Lecture 27.2 Python All Method List Index
print("We use Python Code")

value = [56,89,34,56,32,67,32,67]
print("The First Array List: ",value)

val = [34,65,33,57]
print("The Second Array List: ",val)

print("The Index of 67 is : ",value.index(67))