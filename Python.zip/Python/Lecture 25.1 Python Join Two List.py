# Lecture 25.1 Python Join Two List

print("We use Python Code")

value = [56,89,34,56,32,67]
print("The First Array List: ",value)

val = [34,65,33,57]
print("The Second Array List: ",val)


print("The Join List: ", value+val)