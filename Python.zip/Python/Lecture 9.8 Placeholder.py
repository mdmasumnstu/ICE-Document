#Lecture 9.8 python Placeholder;
print("We use Number data type");

#Place Holder

num = 23

text = f"This is price and value is {num}"
print(num)

second = f"This is value with decimal {num:.2f}"
print(second)