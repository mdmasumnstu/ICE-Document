# Lecture 40.5 Python Delete Set Item 
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

del value
#If print delete value it shows name of 'value' is not defined
print(value)

data = Num.clear()
print(data)


