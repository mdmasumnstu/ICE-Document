# Lecture 14 Python Assignment Operator
print("We use Python Code")

num1 = 34
num2 = 3

print(f"num1: {num1} \nnum2: {num2}")

print(a)





'''num1 += num2
num1-=num2
num1*=num2
num1/=num2
num1%=num2
num1//=num2

print(num1+=num2)
print(num1-=num2)

print(num1*=num2)
print(num1/=num2)

print(num1%=num2)
print(num1//=num2)   '''