# Lecture 25 Python Copy List

print("We use Python Code")

value = [56,89,34,56,32,67]
print(value)

copyvalue = value.copy()
print(copyvalue)


