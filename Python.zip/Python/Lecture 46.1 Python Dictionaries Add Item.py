# Lecture 46.1 Python Dictionaries Add Item
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    }
    
print(info)

info["Degree"]= "BBA"
print(info)

info["Profession"]= "Teaching"
print(info)