# Lecture 45.1 Python Dictionaries Change Item
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    "Department": "Information and Communication Engineering",
    }
    
print(info)

info["Name"]= "Abir"
print(info)

info["Department"]= "Computer Science and Engineering"
print(info)


'''
if "year" in info:
    print("Yes, Year is exist in the Dictionaries")
    
else:
    print("No, Exist in the Distionaries")
    
 '''