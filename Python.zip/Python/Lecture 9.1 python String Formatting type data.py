#Lecture 9.1 python String Formatting type data;
print("We use Number data type");

#String Formatting type data number

first = "Hafizur"
last = "Rahman"

print(f"This is firstname: {first} and lastname: {last}")
print(f"Full name is: ", first+' ' +last)