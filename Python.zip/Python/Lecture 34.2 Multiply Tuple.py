# Lecture 34.2 Multiply Tuple
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
Num= (34,78,5,3)

multi= Num*2
print(multi)

print(value*2)
