# Lecture 33.1 Loop Tuple Through Loop
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")

for x in value:
    print(x)

