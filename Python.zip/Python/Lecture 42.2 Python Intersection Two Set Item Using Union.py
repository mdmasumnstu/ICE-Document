# Lecture 42.2 Python Intersection Two Set Item Using Union
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.intersection(Num)
print("Join Two Set: ", add)
