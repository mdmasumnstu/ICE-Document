#Lecture 9.5 python String Split;
print("We use Number data type");

#String Split

first = "Hafizur, Rahman"

a= first.split(",")

print(first)
print(a)