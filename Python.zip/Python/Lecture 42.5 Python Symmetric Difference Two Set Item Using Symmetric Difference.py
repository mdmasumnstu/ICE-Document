# Lecture 42.5 Python Symmetric Difference Two Set Item Using Symmetric Difference
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal",3,8}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.symmetric_difference(Num)
print("Difference Two Set: ", add)
