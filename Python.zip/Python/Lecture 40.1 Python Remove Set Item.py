# Lecture 40.1 Python Remove Set Item 
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

value.remove("India")
print(value)

Num.remove(78)
print(Num)


