# Lecture 21.2 Python  Data Removes pop
print("We use Python Code")

value = [23,54,56,34,29,75]
print(value)

value.pop(3)
print(value)

list = ["Dhaka","Chattogram","Sylhet","Khulna"]
print(list)

list.pop(2)
print(list)


