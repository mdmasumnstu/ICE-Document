# Lecture 48.2 Python Dictionaries Copy with Dictionary
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    }
    
print(info)

copydic = dict(info)
print("The Copied Value: ",copydic)

'''
newInfo = info.copy()
print(newInfo)
'''


