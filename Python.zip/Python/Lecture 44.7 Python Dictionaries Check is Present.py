# Lecture 44.7 Python Dictionaries Check is Present
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    "Department": "Information and Communication Engineering",
    }
    
print(info)

if "year" in info:
    print("Yes, Year is exist in the Dictionaries")
    
else:
    print("No, Exist in the Distionaries")