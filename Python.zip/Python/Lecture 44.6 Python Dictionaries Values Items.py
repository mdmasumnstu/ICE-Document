# Lecture 44.6 Python Dictionaries Values Items
print("We use Python Code")

studentinfo = {
       "Amin":{
       "Full Name": "Md Amin Ahsan",
       "Location": "Dhaka",
       "Age": 32
       },
       
       "Akash":{
       "Full Name": "Akash Ahsan",
       "Location": "Noakhali",
       "Age": 23
       },
       
       "Shamin":{
       "Full Name": "Md Shamim Hasan",
       "Location": "Chattogram",
       "Age": 26
       },
       "Department": "information and Communication"
}

# print(studentinfo["Shamin"]["Location"])

# info = studentinfo.get("Akash")

# info = studentinfo.keys()

info = studentinfo.values()
print(info)
