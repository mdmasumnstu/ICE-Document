# Lecture 15 Swapping Value
print("We use Python Code")

a= 12
b=32

print("The Value of A: ",a)
print("The Value of B: ",b)

a,b= b,a

print("The Value of A: ",a)
print("The Value of B: ",b)

c = 45
d = 78
print("The Value of C: ",c)
print("The Value of D: ",d)

temp=a
a=b
b=temp

print("The Value of C: ",c)
print("The Value of D: ",d)