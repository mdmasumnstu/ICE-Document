# Lecture 42.7 Python IsSubset Two Set Item Using IsSubset
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal",3,8}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.issubset(Num)
print("Set: ", add)

val = {"Bangladesh","Nepal"}
check = val.issubset(value)
print("Set: ",check)
