# Lecture 21.3 Python  Data Removes Delete
print("We use Python Code")

value = [23,54,56,34,29,75]
print(value)

del value[1]
print(value)

list = ["Dhaka","Chattogram","Sylhet","Khulna"]
print(list)

del list[3]
print(list)


