# Lecture 12.3 Python Sequence Type Data
print("We use Python Range Code")

value= 5;
a= range(1, value+1)
print(a)

for i in a:
        print(i)
