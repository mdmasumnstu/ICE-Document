# Lecture 42.4 Python isDisjoint Two Set Item Using isDisjoint
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal",3,8}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.isdisjoint(Num)
print("Difference Two Set: ", add)
