# Lecture 24.1 Python Sort List Alphanumerically
print("We use Python Code")

value = [56,89,34,56,32,67]
print(value)

value.sort()
print(value)


place = ["Dhaka","Khulna","Sylhet","Barishal"]
print(place)

place.sort()
print(place)

