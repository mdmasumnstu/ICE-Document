# Lecture 33.2 Loop Tuple Through For Loop and Index
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")

for i in range(len(value)):
    print(i)
    print(value[i])

