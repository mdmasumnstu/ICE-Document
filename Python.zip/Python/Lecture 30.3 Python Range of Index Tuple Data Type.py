# Lecture 30.3 Python Range of Index Tuple Data Type  
print("We use Python Code")

value = ("Dhaka","Sylhet", "Chattogram","Rangpur",24,56,False,True,43,"Mymensingh",True)
print(value[2: ])

