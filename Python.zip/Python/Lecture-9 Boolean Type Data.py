#Lecture 9 python Boolean type data;
print("We use Number data type");

#Boolean type data number

data= True;
number = False;

print(number)
print(type(data))

a = 23
b =88

print("Check A is greater than B: ",a>b)
print(type(a>b))
