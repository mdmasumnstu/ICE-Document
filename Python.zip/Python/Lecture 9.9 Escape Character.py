#Lecture 9.9 python Escape Character;
print("We use Python Code");

#Escape Character

print("This is newline \f escape \\ character \" use. \nThis is the \r newline")
print("An example of \t an illegal \bcharacter is a double quote \ninside a string that is surrounded by double quotes")