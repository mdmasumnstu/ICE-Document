# Lecture 42.1 Python Join Two Set Item Using Union
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.union(Num)
print("Join Two Set: ", add)
