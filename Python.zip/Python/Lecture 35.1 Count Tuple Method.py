# Lecture 35.1 Count Tuple Method
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
Num= (34,78,5,3,5,5,3)

print(value.count("India"))
print(Num.count(5))
