# Lecture 21.1 Python  Data Removes
print("We use Python Code")

value = [23,54,56,34,29,75]
print(value)

value.remove(56)
print(value)

list = ["Dhaka","Chattogram","Sylhet","Khulna"]
print(list)

list.remove("Chattogram")
print(list)


