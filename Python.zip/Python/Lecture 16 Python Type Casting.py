# Lecture 16 Python Type Casting
print("We use Python Code")

value= "345656"
a = int(value)
print(value)
print(type(int(value)))

num= float(34)
print(type(float(34)))

num= str(34)
print(type(str(34)))

num= int(34.67)
print(type(int(34)))