# Lecture 32.1 Unpacking Tuple
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
(Dhaka,Delhi,Islamabad,Kathmandu) = value

print(Dhaka)
print(Delhi)
print(Islamabad)
print(Kathmandu)