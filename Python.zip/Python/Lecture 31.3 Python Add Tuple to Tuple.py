# Lecture 31.3 Python Add Tuple to Tuple
print("We use Python Code")

value = ("Dhaka","Sylhet",True,"Rangpur",24,56,False)
newvalue = ("Bangladesh","Nepal",)

value +=newvalue
print(value)

