#Lecture 10.1 Python Binary Data Type;
print("We use Python Code");

numlist = [23,45,4,3,7,76]
a= bytes(numlist)
a[4]= 5
print(a)


print(type(a))

