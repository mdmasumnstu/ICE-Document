# Lecture 40.3 Python POP Set Item 
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

val = value.pop()
print(val)

data = Num.pop()
print(data)


