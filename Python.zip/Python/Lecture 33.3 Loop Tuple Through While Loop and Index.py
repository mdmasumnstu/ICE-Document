# Lecture 33.3 Loop Tuple Through While Loop and Index
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")

i=0

while i< len(value):
    print(value[i])
    i=i+1

