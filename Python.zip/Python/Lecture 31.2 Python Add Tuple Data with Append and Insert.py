# Lecture 31.2 Python Add Tuple Data with Append and Insert
print("We use Python Code")

value = ("Dhaka","Sylhet",True, "Chattogram","Rangpur",24,56,False)

listvalue = list(value)
listvalue.append("Jamalpur")

listvalue.insert(3,"Rajshahi")

value = tuple(listvalue)
print(listvalue)
print(type(listvalue))

print(value)
print(type(value))
