# Lecture 16 Python User Input
print("We use Python Code")

firstname= input("Enter Your First Name: ")
lastname= input("Enter Your Last Name: ")

print("First Name: ",firstname)
print("Last Name: ",lastname)

print("Full Name: ", firstname+ " " +lastname)