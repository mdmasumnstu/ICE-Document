# Lecture 42.6 Python IsSuperset Two Set Item Using IsSuperset
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal",3,8}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.issuperset(Num)
print("Difference Two Set: ", add)
