# Lecture 43.1 Python Dictionaries
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Department": "Information and Communication Engineering",
    }
    
print(info)
