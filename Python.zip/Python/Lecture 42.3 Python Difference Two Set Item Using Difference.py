# Lecture 42.3 Python Difference Two Set Item Using Difference
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal",3,8}
print(value)
Num= {34,78,5,3}
print(Num)

add = value.difference(Num)
print("Difference Two Set: ", add)
