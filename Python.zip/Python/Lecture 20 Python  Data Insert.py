# Lecture 20 Python  Data Insert
print("We use Python Code")

listvalue = ["Dhaka","Khulna","Sherpur","Barishal"]

print(listvalue)
print(type(listvalue))

print("Change The Data Element: ")
listvalue[1] = "Mymensingh"
print(listvalue)


value= ["Mymensingh","Sherpur","Jamalpur","Netrokona"]
# a= listvalue.append("Rajshahi")
# print(listvalue)

b= value.insert(3,"Kishoregonj"),value.insert(4,"Tangail")
print(value)

num = [4,6,3,76,23]
d = num.insert(2,34)
print(num)

f = num.append(21)
print(num)


