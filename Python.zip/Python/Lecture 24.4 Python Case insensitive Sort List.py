# Lecture 24.4 Python Case insensitive Sort List
# By default the sort() are case sensitive at where all capital letter sorted being before lower letter
print("We use Python Code")

value = [56,89,34,56,32,67]
print(value)

value.reverse()
print(value)


place = ["Dhaka","khulna","Sylhet","Barishal"]
print(place)

places = ["Dhaka","khulna","sylhet","Barishal"]
print(places)

places.sort()
print(places)

