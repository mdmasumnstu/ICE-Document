#lecture 7 python Number type data;
print("We use Number data type");

#int type data number
first= 3435;
print(first);
print(type(first));

#float type data number
second= 767.86;
print(second);
print(type(second));

#complex type data number
third = 56j;
print(third);
print(type(third));