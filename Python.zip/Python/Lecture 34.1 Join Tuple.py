# Lecture 34.1 Join Tuple
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
Num= (34,78,5,3)

add = value+Num
print(add)

