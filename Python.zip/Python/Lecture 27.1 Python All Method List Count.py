# Lecture 27.1 Python All Method List Count
print("We use Python Code")

value = [56,89,34,56,32,67,32,67]
print("The First Array List: ",value)

val = [34,65,33,57]
print("The Second Array List: ",val)

print("The Value of 67 is : ",value.count(67))