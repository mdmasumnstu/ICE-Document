# Lecture 31.4 Python Remove Tuple Item
print("We use Python Code")

value = ("Dhaka","Sylhet",True,"Rangpur",24,56,False)

tupleval = list(value)
tupleval.remove(True)

print(value)
print(type(tupleval))

value = tuple(tupleval)
print(value)

