# Lecture 14.1 Python Comparision Operator
print("We use Python Code")

a= 12
b=32

print("The Number are Equal: ",a==b)
print("The Number are Equal or Greater Other: ",a>=b)
print("The Number are Equal or Less Than: ",a<=b)
print("The Number are Equal Not Equal",a!=b)
print("The Number are Equal Greater Than: ",a>b)
print("The Number are Equal Less Other: ",a<b)