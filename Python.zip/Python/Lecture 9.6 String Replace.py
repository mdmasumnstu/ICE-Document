#Lecture 9.6 python String Replace;
print("We use Number data type");

#String Replace

first = "Hafizur, Rahman"

a= first.replace("r", "l")

print(first)
print(a)