# Lecture 41.1 Python Loop Set Item Using For Loop
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3}
print(Num)

for x in value:
    print(x)

print("For loop with index: ")

for i in value:
    print(i)
    print(value[i])


