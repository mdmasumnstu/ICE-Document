# Lecture 32.2 Asterisk Unpacking Tuple
print("We use Python Code")

value = ("Bangladesh","India","Pakistan","Nepal")
(Dhaka,Delhi,*Islamabad) = value

print(Dhaka)
print(Delhi)
print(Islamabad)
