# Lecture 30.2 Python Negative Access Tuple Data Type  
print("We use Python Code")

value = ("Dhaka","Sylhet", "Chattogram")
print(value[-2])

