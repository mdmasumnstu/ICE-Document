#lecture 6 python data type
print("We use data type");



#It seems that the semicolon use aren't mandatory
number= 5667678;
print(number);

stringdata= "this is string data type";
print("stringdata");