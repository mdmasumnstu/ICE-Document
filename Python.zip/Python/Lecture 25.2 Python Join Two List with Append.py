# Lecture 25.2 Python Join Two List with Append
print("We use Python Code")

value = [56,89,34,56,32,67]
print("The First Array List: ",value)

val = [34,65,33,57]
print("The Second Array List: ",val)

for x in val:
    value.append(x)
    print(value)