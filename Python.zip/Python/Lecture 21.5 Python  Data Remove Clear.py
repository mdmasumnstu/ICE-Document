# Lecture 21.5 Python  Data Remove Clear
print("We use Python Code")

value = [23,54,56,34,29,75]
print(value)

value.clear()
print(value)

list = ["Dhaka","Chattogram","Sylhet","Khulna"]
print(list)

list.clear()
print(list)



