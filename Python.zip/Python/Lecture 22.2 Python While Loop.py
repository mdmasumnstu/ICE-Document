# Lecture 22.2 Python While Loop
print("We use Python Code")

value = ["Dhaka","Rajshahi","Khulna","Sylhet"]
print(value)

i= 0
while i< len(value):
    print(i)
    print(value[i])
    i = i+1
