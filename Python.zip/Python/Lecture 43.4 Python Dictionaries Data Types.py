# Lecture 43.4 Python Dictionaries Data Types
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    "Department": "Information and Communication Engineering",
    }
    
print(info)

# print(type(info))

print(len(info))