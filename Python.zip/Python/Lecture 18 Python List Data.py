# Lecture 18 Python List Data
print("We use Python Code")

listvalue = ["Dhaka","Khulna","Sherpur","Barishal"]

print(listvalue)
print(type(listvalue))

listvalue[1] = "Mymensingh"
print(listvalue)

value= [1,3,4,56,7]
print(value)
print(type(value))

data = [True,False,False,True]
print(data)
print(type(data))
