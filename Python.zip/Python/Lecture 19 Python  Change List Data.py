# Lecture 19 Python  Change List Data
print("We use Python Code")

listvalue = ["Dhaka","Khulna","Sherpur","Barishal"]

print(listvalue)
print(type(listvalue))

listvalue[1] = "Mymensingh"
print(listvalue)


