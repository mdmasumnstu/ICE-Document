# Lecture 11 Python Binary None Type
print("We use Python Code")

num= None
a = " "
print(num)
print(a)

print(type(num))
print(type(a))