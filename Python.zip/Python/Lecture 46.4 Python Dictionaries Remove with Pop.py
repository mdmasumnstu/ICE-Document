# Lecture 46.4 Python Dictionaries Remove with Pop
print("We use Python Code")

info= {
    "Name": "Amin",
    "Location" :"Dhaka",
    "Year" : 2026,
    "Married": False,
    "Favourite Color": ["Green","Blue","Orange"],
    }
    
print(info)

'''
info.update({"Date of Birth": "15/02/2003"})
print(info)
'''

'''
info["Degree"]= "BBA"
print(info)

info["Profession"]= "Teaching"
print(info)
'''
info.pop("Year")
print(info)



