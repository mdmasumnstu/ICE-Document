# Lecture 39.1 Python Add Set Item
print("We use Python Code")

value = {"Bangladesh","India","Pakistan","Nepal"}
print(value)
Num= {34,78,5,3,5,5,3}
print(Num)

value.add("Maldives")
print(value)

Num.add(44)
print(Num)

