# Lecture 12.2 Python Sequence Type Data
print("We use Python Code")

print("We can't change the value of list in sequence")
value = ("Apple","Banana", "Cherry")
print(value)

print("That is not posible because tuple are always fixed value")
value[2]= "Orange"
print(value)
