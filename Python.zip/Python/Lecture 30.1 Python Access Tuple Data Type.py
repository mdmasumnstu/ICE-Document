# Lecture 30.1 Python Access Tuple Data Type  
print("We use Python Code")

value = ("Dhaka","Sylhet", "Chattogram")
print(value[1])