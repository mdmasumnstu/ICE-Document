# Lecture 24.3 Python Sort List Reverse Order
print("We use Python Code")

value = [56,89,34,56,32,67]
print(value)

value.reverse()
print(value)


place = ["Dhaka","Khulna","Sylhet","Barishal"]
print(place)

place.reverse()
print(place)

