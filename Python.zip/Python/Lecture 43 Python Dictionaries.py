# Lecture 43 Python Dictionaries
print("We use Python Code")

studentinfo = {
       "Amin":{
       "Full Name": "Md Amin Ahsan",
       "Location": "Dhaka",
       "Age": 32
       },
       
       "Akash":{
       "Full Name": "Akash Ahsan",
       "Location": "Noakhali",
       "Age": 23
       },
       
       "Shamin":{
       "Full Name": "Md Shamim Hasan",
       "Location": "Chattogram",
       "Age": 26
       }
}

print(studentinfo["Amin"])
