#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    int a, c;
    long long int b, d,m,n;
    cin >> a >> b >> c >> d;

    m = pow(a, b);
    n = pow(c, d);

    if (m > n) 
    {
        cout << "YES" << endl;
    } 
    else 
    {
        cout << "NO" << endl;
    }

    return 0;
}
