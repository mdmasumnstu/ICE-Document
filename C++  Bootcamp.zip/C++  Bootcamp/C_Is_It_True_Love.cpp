#include <iostream>
using namespace std;

int main()
{   
    int t;
    cin >> t; 
    
    while(t--) 
    {
        int n;
        cin >> n;
        int m = 0; 
  
        if (n <= 1)
        {
            cout << "no" << endl;
            continue; 
        }
  
        for (int i = 2; i * i <= n; i++) 
        {
            if (n % i == 0)
            {
                m = 1;
                break;
            }
        }
        
        if (m == 0)
            cout << "yes" << endl;  
        else
            cout << "no" << endl;  
    }
}
