#include <iostream>
#include <string>

int main() {
    int t;
    std::cin >> t;
    while (t--) {
        std::string n;
        std::cin >> n;
        long long sum_of_digits = 0;
        for (char digit : n) {
            sum_of_digits += digit - '0';
        }

        if (sum_of_digits == 0) {
            std::cout << 0 << std::endl;
        } else if (sum_of_digits % 9 == 0) {
            std::cout << 9 << std::endl;
        } else {
            std::cout << sum_of_digits % 9 << std::endl;
        }
    }
    return 0;
}