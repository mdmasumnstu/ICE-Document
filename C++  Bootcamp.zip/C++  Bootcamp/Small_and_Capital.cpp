#include<iostream>
using namespace std;
int main()
{
    string s;
    cin>>s;

    int n= s.length();
    int i,cap=0,smp=0;

    for(i=0;i<n;i++)
    {
        if(s[i]>='a' && s[i]<='z')
        {
            smp++;
        }

        if(s[i]>='A' && s[i]<='Z')
        {
            cap++;
        }
    }
    cout<<cap<<" "<<smp<<endl;
}