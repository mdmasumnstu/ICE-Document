#include<iostream>
using namespace std;
int main()
{
    long long int a,b;
    cin>>a >>b;

    cout<<a << " + " << b<< " = " << a+b<<endl;
    cout<<a << " * " << b<< " = " << a*b<<endl;
    cout<<a << " - " << b<< " = " << a-b<<endl;
}