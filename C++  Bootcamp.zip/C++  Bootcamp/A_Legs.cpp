#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,m=0,a=0;
        if(n%4==0)
        {
            m++;
            if(m%2==0)
            {
                m++;
            }
          
        }
        else if(n%2==0)
        {
            a++;
        }
        cout<<m<<endl;
        cout<<a<<endl;
    }
}