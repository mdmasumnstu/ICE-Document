#include <iostream>
using namespace std;

int main() 
{
    long long A, B, C, D;
    cin >> A >> B >> C >> D;

    long long product = A * B * C * D;

    int n = product % 100;

    cout << n << endl;

    return 0;
}
