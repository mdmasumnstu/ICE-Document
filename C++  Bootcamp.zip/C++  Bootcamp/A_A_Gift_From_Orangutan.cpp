#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int n,a[n],i,j,temp,sum=0,dif=0;
        cin>>n;

        for(i=0;i<n;i++)
        {
            cin>>a[i];
        }

        for(i=0;i<10-1;i++)
        {
            for(j=i+1;j<10;j++)
            {
                if(a[i]>a[j])
                {
                    temp=a[i];
                    a[i]=a[j];
                    a[j]=temp;
                }
            dif=a[j]-a[0];
             sum=sum+dif;
             }
             
        }
    cout<<sum<<endl;

    }
}