#include<iostream>
using namespace std;

int n,i;
    cin >> n;
    int a[n];
    
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }

    int value,m=0;
    cin>>value;
    
    for(i=0;i<n;i++)
    {
        if(a[i]==value)
        {
            m++;
        }
    }

    cout<<m<<endl;
    return 0;