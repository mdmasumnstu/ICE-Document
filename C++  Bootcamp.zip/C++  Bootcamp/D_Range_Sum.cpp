#include <iostream>
using namespace std;

int main() {
    int T;
    cin >> T;

    while (T--) 
    {
        long long a,b;
        cin >> a >> b;

        long long sum = 0;
        for (long long i = a; i <= b; ++i) 
        {
            sum += i;
        }

        cout << sum << endl;
    }

    return 0;
}
