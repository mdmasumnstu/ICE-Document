#include<iostream>
using namespace std;
int main()
{
    int a,b,d,c,sum
    cin>>a>>b;
    c=a%10;
    d=b%10;
    sum =c+d;
    cout<<sum<<endl;
}