#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    string s,m;
    getline(cin,s);

    ;
    cout<<strrev(s)<<endl;
}