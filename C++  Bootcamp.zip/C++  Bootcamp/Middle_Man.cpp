#include<iostream>
#include<algorithm> // Include algorithm for sort function
using namespace std;

int main() 
{
    int n;
    cin >> n;
    int a[n], i;

    for (i = 0; i < n; i++) 
    {
        cin >> a[i];
    }

    sort(a, a + n);

    if (n % 2 == 1) 
    {
        cout << a[n / 2] << endl;
    } 
    else 
    {
        cout << a[n / 2 - 1] << " " << a[n / 2] << endl;
    }

    return 0;
}
