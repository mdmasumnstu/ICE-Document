#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    for(int m=1;m<=t;m++)
    {
        string s;
        cin>>s;
        int a=0,b=0;
        for(int i=0;i<5;i++)
        {
            if(s[i]=='A')
            {
                a++;
            }
            else if(s[i]=='B')
            {
                b++;
            }
        
        }
        if(a>b)
        {
            cout<<"A"<<endl;
        }
        else{
            cout<<"B"<<endl;
        }
    }
}
