#include <iostream>
#include <string>
using namespace std;

void print(int a)
{
    if(a%2==1)
    {
        cout<<"YES"<<endl;
    }
}

void prin(int b)
{
    if(b%2==0)
    {
        cout<<"NO"<<endl;
    }
}

int main() 
{
    int a;
    cin>>a;
    print(a);
    prin(a);
    return 0;
}
