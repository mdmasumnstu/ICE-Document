#include <iostream>
using namespace std;

int main() {
    int q;
    cin >> q;  // Number of queries

    while (q--) {
        long long n;
        cin >> n;  // Input for each query
        int moves = 0;  // Initialize move counter

        // Process division by 2
        while (n % 2 == 0) {
            n /= 2;
            moves++;
        }

        // Process division by 3
        while (n % 3 == 0) {
            n = (2 * n) / 3;
            moves++;
        }

        // Process division by 5
        while (n % 5 == 0) {
            n = (4 * n) / 5;
            moves++;
        }

        // Check if it is possible to reduce n to 1
        if (n != 1) {
            cout << -1 << endl;
        } else {
            cout << moves << endl;
        }
    }

    return 0;
}
