#include <iostream>
#include<cmath>
using namespace std;

int main() 
{
  
        long long int a, b;
        cin >> a >> b;

        if (a > b) 
        {
            swap(a, b);
        }

        long long int sum = 0,evenSum=0,OddSum=0;

        for(int i=a;i<=b;i++)
        {
            sum= sum+i;
            if(i%2==0)
            {
                evenSum +=i;
            }
            if(i%2 !=0)
            {
                OddSum +=i;
            }
        }
        cout << sum << endl;
        cout<<evenSum<<endl;
        cout<<OddSum<<endl;
   

    return 0;
}
