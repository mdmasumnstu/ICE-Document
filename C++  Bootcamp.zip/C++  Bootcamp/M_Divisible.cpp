#include<iostream>
using namespace std;
int main()
{
    long long int a,b;
    cin>>a>>b;

    if(a%b==0)
    {
        cout<<"YES"<<endl;
    }
    else
    {
        cout<<"NO"<<endl;
    }
}