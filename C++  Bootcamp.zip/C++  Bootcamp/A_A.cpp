#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    long long B;
    cin >> B;
    
    long long A = round(cbrt(B)); 
    if ((A * A * A) == B) 
    {
        cout << A << endl;
    } else 
    {
        cout << -1 << endl;
    }
    
    return 0;
}
