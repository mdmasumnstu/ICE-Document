#include<iostream>
using namespace std;
int main()
{
    int n,p=0,t=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        int a,b;
        cin>>a>>b;
        if(a>b)
        {
            t++;
        }
        else if (a<b)
        {
           p++;
        }

        
        
    }
    if(t>p)
    {
        cout<<"Tiger"<<endl;
    }
    else if(t<p)
    {
        cout<<"Pathan"<<endl;
    }
    else if(t==p)
    {
        cout<<"Draw"<<endl;
    }
}