#include<iostream>
using namespace std;
int main()
{
    int t,sum=0,rev=0,m,temp;
    cin>>t;
    temp=t;
    while(temp > 0)
    { 
        sum = sum+ temp % 10; 
        temp = temp / 10;
    }

   temp = sum; 
   cout<<temp<<endl; 

    while ( temp > 0)  
    {  
        rev = rev * 10 + temp % 10;  
        temp = temp / 10;  
    }

    cout<<rev<<endl;

    m = rev*sum;
    if(m==t)
    {
        cout<<"YES"<<endl;
    }
    else
    {
        cout<<"NO"<<endl;
    }
}