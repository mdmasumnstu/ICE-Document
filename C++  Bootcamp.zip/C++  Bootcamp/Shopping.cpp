#include <iostream>
using namespace std;

int main() {
    int N;
    cin >> N;

    int initial_money = 1600;
    int punjabi_cost = 1000;
    int shoes_cost = 500;

    int total_money = initial_money + N;

    if (total_money > punjabi_cost) {
        cout << "I will buy Punjabi" << endl;
        total_money -= punjabi_cost;

        if (total_money >= shoes_cost) {
            cout << "I will buy new shoes" << endl;
            cout << "Alisa will buy new shoes" << endl;
        } else {
            cout << "Bad luck!" << endl;
        }
    } else {
        cout << "Bad luck!" << endl;
    }

    return 0;
}
