#include<iostream>
using namespace std;
int main()
{
 long long a,b,c,d,m,n;
 cin>>a;
 cin>>b;
 cin>>c;
 cin>>d;

 m=a*b;
 n=c*d;
 cout<<m<<endl;
 cout<<n<<endl;

}