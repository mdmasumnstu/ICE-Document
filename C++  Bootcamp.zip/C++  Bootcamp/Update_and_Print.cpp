#include<iostream>
using namespace std;
int main()
{
	int t;
 
	scanf("%d", &t);
	
	int i,a[t];
	for(i=0;i<t;i++)
	{
		scanf("%d", &a[i]);
	}
		int index,value;
        scanf("%d %d", &index,&value);

        a[index]=value;

	for(i=(t-1);i>=0;i--)
	{	
           printf("%d ", a[i]);
	}
}