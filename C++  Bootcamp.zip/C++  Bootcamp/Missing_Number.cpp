#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        int a,b,c,d,e;
        cin>>a>>b>>c>>d;
         e= a-(b+c+d);
         cout<<e<<endl;
    }
}