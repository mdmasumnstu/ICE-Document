#include <iostream>
#include <iomanip> // For std::setprecision
using namespace std;

int main() 
{
    int t;
    cin >> t;

    while (t--) 
    {
        int X, Y;
        cin >> X >> Y;

        if (Y == 0) 
        {
            cout << "divisao impossivel" << endl;
        } 
        
        else 
        {
            cout << fixed << setprecision(1) << float (X) / Y << endl;
        }
    }

    return 0;
}
