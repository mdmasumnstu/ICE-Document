#include <iostream>
#include <algorithm>
#include<cmath>
using namespace std;

int main()
 {  
    int t;  
    cin >> t;

    while (t--) 
    {
        int n;
        cin>>n;
        int a[n],sum=0,b;
        for(int i=0;i<n;i++)
        {
            cin>>a[i];
            sum=abs(a[i]-a[i+1]);
        }
        for(int i=0;i<n;i++)
        {
            b=  abs(a[n-1]-a[0]);
        }
    cout<<sum+b<<endl;
    }
}
