#include <iostream>
#include <iomanip> // For std::setprecision
using namespace std;

void plusMinus(int arr[], int n) {
    int pos = 0, neg = 0, zero = 0;

    // Count positive, negative, and zero values
    for (int i = 0; i < n; i++) {
        if (arr[i] > 0) {
            pos++;
        } else if (arr[i] < 0) {
            neg++;
        } else {
            zero++;
        }
    }

    // Calculate ratios
    double posRatio = static_cast<double>(pos) / n;
    double negRatio = static_cast<double>(neg) / n;
    double zeroRatio = static_cast<double>(zero) / n;

    // Print ratios with six decimal places
    cout << fixed << setprecision(6);
    cout << posRatio << endl;
    cout << negRatio << endl;
    cout << zeroRatio << endl;
}

int main() {
    int n;
    cin >> n;
    int arr[n];

    // Input array elements
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    // Call the plusMinus function
    plusMinus(arr, n);

    return 0;
}
