#include <iostream>
#include <string>
using namespace std;

int is_palindrome(const string& S) 
{
    int n = S.size();
    for (int i = 0; i < n / 2; ++i) 
    {
        if (S[i] != S[n - 1 - i]) 
        {
            return 0; 
        }
    }
    return 1; 
}

int main()
 {
    string S;

    cin >> S;

    int result = is_palindrome(S);

    if (result == 1) {
        cout << "Palindrome" << endl;
    } else {
        cout << "Not Palindrome" << endl;
    }

    return 0;
}
