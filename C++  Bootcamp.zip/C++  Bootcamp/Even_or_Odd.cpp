#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    
    int a[t],i;
    for(i=1;i<=t;i++)
    {
        cin>>a[i];
    }
    for(i=1;i<=t;i++)
    {
        if(a[i]==0)
        {
            cout<<"NULL"<<endl;
        }
        else if(a[i]%2==0 && a[i]>0)
        {
            cout<<"EVEN POSITIVE"<<endl;
        }
        else if(a[i]%2==0 && a[i]<0)
        {
            cout<<"EVEN NEGATIVE"<<endl;
        }
        else if(a[i]%2 !=0 && a[i]>0)
        {
            cout<<"ODD POSITIVE"<<endl;
        }
        else if(a[i]%2!=0 && a[i]<0)
        {
            cout<<"ODD NEGATIVE"<<endl;
        }
    }
}