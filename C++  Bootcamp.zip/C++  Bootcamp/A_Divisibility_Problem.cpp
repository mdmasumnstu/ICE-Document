#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int a,b,m=0,i;

        for(i=a;(a%b!=0);i++)
        {
            
                 m++;
            
        }
        cout<<m<<endl;
    }
}