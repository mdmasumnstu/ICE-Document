#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n],i,count=0;

    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }

    for(i=0;i<n;i++)
    {
        count++;
        if(a[i]==1)
        {
            break;
        }
    }
    cout<<count-1<<endl;

}