#include <iostream>
#include <cmath>
using namespace std;

int main() {
    int t;
    cin >> t;
    
    while (t--) 
    {
        int n, k, p,max,min;
        cin >> n >> k >> p;
        
        
        max = n * p;
        min = n * (-p);
        
        
        if (k > max || k < min) 
        {
            cout << -1 << endl;
        } 
        else 
        {
            
            int tar = abs(k);
            int oper = (tar + p - 1) / p; 
            cout << oper << endl;
        }
    }
    
    return 0;
}
