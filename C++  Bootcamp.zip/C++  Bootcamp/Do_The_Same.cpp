#include<iostream>
using namespace std;
int main()
{
    int n,t;
    cin>>n>>t;

    for(int j=1;j<=t;j++)
    {
        for(int i=1;i<=n;i++)
    {
        cout<<i<<" ";
    }
    cout<<endl;
    }
}