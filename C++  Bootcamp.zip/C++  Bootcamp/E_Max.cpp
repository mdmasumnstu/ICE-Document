#include<iostream>
using namespace std;
int main()
{
    int t,i,maxNum=0;
    for(i=0;i<t;i++)
    {
        int n;
        cin>>n;

        maxNum= max(maxNum,n);
    }
    cout<<maxNum<<endl;
}