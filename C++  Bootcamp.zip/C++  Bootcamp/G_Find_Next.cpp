
#include<iostream>
using namespace std;
int main()
{
    int test;
    cin>>test;
    while(test--)
    {
        int L, M, N, dif, next;
        cin>>L>>M>>N;

        dif=M-L;
        next= dif*N + M;
        cout<<next<<endl;

    }
}