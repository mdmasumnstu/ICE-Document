#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main() 
{

    int i = 4;
    double d = 4.0;
    string s1 = "HackerRank ";

    int a;
    double b;
    string s;

    cin >> a;
    cin >> b;
    cin.ignore();
    getline(cin, s);

    cout << i + a << endl;

    cout << fixed << setprecision(1) << d + b << endl;

    cout << s1 + s << endl;

    return 0;
}
