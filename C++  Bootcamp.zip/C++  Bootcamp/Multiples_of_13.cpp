#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    int a,b,i,sum=0;
    cin>>a>>b;

    if (a > b) 
    {
        swap(a, b);
    }

    for(i=a;i<=b;i++)
    {
        if(i%13 !=0)
        {
            sum=sum+i;
        }
    }
    cout<<sum<<endl;
}