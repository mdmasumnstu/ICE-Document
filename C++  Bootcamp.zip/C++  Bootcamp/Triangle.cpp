#include<iostream>
using namespace std;
int main()
{
    float a,b,c,perimeter,area;
    cin>>a>>b>>c;

    if((a+b>c) && (b+c>a) && (a+c>b))
    {
        perimeter= a+b+c;
        printf("Perimetro = %.1f\n",perimeter);
    }
    else
    {
        area= ((a+b)*c)/2;
        printf("Area = %.1f\n",area);
    }
}