#include<iostream>
using namespace std;
int main()
{
   cout<<"Enter the variable"<<endl;
   return 0;
}