#include <iostream>
using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        int n;
        cin >> n;
        int switches[2 * n];

        // Reading the states of the switches
        for (int i = 0; i < 2 * n; i++) {
            cin >> switches[i];
        }

        int countOn = 0;

        // Counting the number of switches that are on
        for (int i = 0; i < 2 * n; i++) {
            if (switches[i] == 1) {
                countOn++;
            }
        }

        // Minimum number of lights that can be turned on
        int minLightsOn = max(0, countOn - n);

        // Maximum number of lights that can be turned on
        int maxLightsOn = min(n, countOn);

        cout << minLightsOn << " " << maxLightsOn << endl;
    }

    return 0;
}
