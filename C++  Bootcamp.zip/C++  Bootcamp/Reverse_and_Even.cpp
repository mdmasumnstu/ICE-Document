#include<iostream>
using namespace std;
int main()
{
	int t;
 
	scanf("%d", &t);
	
	int i,a[t];
	for(i=0;i<t;i++)
	{
		scanf("%d", &a[i]);
	}
		
	for(i=(t-1);i>=0;i=i-1)
	{
		if(i%2==0)
        {
            printf("%d ", a[i]);
        }
	}
}