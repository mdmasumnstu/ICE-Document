#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int num,a,m; long long n;
    cin>>n;

    num = 1378;
    a = num % 10;

    double b=pow(a,n);
    m = b % 10;
    cout<<m<<endl;

}