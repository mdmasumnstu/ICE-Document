#include <iostream>
using namespace std;

int main() 
{
    long long int a,b,lcm;
    cin>>a>>b;

    long long int gcd=1;
    for(long long int i=1;i<=a && i<=b;i++)
    {
        if(a%i==0 && b%i==0)
        {
            gcd=i;
        }
    }
    lcm= (a*b)/gcd;

    cout<<gcd<<" "<<lcm<<endl;
    return 0;
}