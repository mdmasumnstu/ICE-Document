#include<iostream>
using namespace std;
int main()
{
    int a,b,i;
    cin>>a>>b;
    for(i=a;i<=b;i++)
    {
        if(i==4 || i==7 || i==44|| i==47 || i==74 ||i==77 || i==444 || i==447 || i==474 || i==744 || i==477 || i==747 || i==774 || i==777 )
        cout<<i<<" ";
        else
        cout<<"-1"<<endl;
    }
}