   #include<iostream>
    using namespace std;
    
    void odd_even()
    {
        int n;
        cin>>n;
        int a[n],i,even=0,odd=0;

        for(i=0;i<n;i++)
        {
            cin>>a[i];
        }

        for(i=0;i<n;i++)
        {
            if(a[i]%2==0)
            {
                even++;
            }
            else
            {
                odd++;
            }
        }
        cout<<even<<" "<<odd<<endl;
    }

    int main()
   {
    odd_even();
    return 0;
   }
