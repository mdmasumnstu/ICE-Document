#include<iostream>
using namespace std;
int main()
{
    int n,i,j;
    int a[n][n];

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            cin>>a[i][j];
        }
        cout<<endl;
    }

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i == j && a[i][j] != 1)
            {
                cout<<"YES"<<endl;
            }
            else{
                cout<<"NO"<<endl;
            }
        }
        cout<<endl;
    }
}