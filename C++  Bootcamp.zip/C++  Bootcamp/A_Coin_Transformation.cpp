#include <iostream>
#include <cmath>
using namespace std;

int main() 
{
    int t;
    cin >> t;

    while (t--) 
    {
        long long n,a=1;
        cin >> n; 

        if (n > 3) 
        {
            
            while (n > 3) 
            {
               n=n/4;
               a=2*a;
                
            }
        }

        cout <<a << endl;
    }

    return 0;
}
