#include<iostream>
using namespace std;
int main()
{
    int n, a[n],inc=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }

    for(int i=0;i<n;i++)
    {
        if(a[i]<a[i+1])
        {
            inc++;
        }
        else if(a[i]==a[i+1])
        {
            inc=1;
        }
    }
    if(inc!=0)
    {
        cout<<inc<<endl;
    }
  
}