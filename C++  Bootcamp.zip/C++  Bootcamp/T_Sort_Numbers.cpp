#include<iostream>
using namespace std;
int main()
{
    int a,b,c;
    cin>>a>>b>>c;

    if(a>b && a>c)
    {
        if(b>c)
        {
            out<<a<<endl<<b<<endl<<c<<endl<<endl;
            cout<<c<<endl<<b<<endl<<a<<endl;
        }
        else{
            cout<<a<<endl<<b<<endl<<c<<endl<<endl;
            cout<<c<<endl<<b<<endl<<a<<endl;
        }
    }
    else if(b>a && b>c)
    {
        if(a>c)
        {
            cout<<a<<endl<<c<<endl<<b<<endl<<endl;
            cout<<b<<endl<<c<<endl<<a<<endl;
            
            
        }
        else{
            cout<<c<<endl<<a<<endl<<b<<endl<<endl;
            cout<<b<<endl<<a<<endl<<c<<endl;
        }
    }

    if(c>a && c>b)
    {
        if(a>b)
        {
            cout<<a<<endl<<b<<endl<<c<<endl;
            cout<<c<<endl<<b<<endl<<a<<endl;
           
            
        }
        else{
             cout<<b<<endl<<a<<endl<<c<<endl<<endl;
            cout<<c<<endl<<a<<endl<<b<<endl;
            
        }
    }

}
