#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        int h,m,total,min=1440;
        cin>>h>>m;

        total= (h*60)+m;
        int minute= min-total;

        cout<<minute<<endl;

    }
}