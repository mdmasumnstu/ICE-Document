#include <iostream>
using namespace std;

int count_before_one(int n, int a[])
 {
    int count = 0;
    for (int i = 0; i < n; i++)
     {
        if (a[i] == 1) 
        {
            break;
        }
        count++;
    }
    return count;
}

int main() 
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) 
    {
        cin >> a[i];
    }

    int c = count_before_one(n, a); 
    cout << c << endl; 

    return 0;
}
