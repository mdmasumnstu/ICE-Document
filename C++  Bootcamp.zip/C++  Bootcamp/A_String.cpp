#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        string s;
        cin>>s;
        int len=s.length();
        int m=0;
        for(int i=0;i<len;i++)
        {
            if(s[i]=='1')
        	{
		
                m++;
            }
        }
        cout<<m<<endl;
	}
}
