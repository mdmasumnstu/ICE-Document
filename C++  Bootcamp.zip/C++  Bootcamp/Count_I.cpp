#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n],i,even=0,odd=0;

    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }

    for(i=0;i<n;i++)
    {
        if(a[i]%2==0)
        {
            even++;
        }
        else if(a[i]%2 !=0)
        {
            odd++;
        }
    }
    cout<<even<<" "<<odd<<endl;

}