#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int t; // Number of test cases
    cin >> t;
    
    while (t--) {
        int n; // Length of the array
        cin >> n;
        
        int a[n]; // Array of integers
        for (int i = 0; i < n; ++i) {
            cin >> a[i];
        }
        
        // Find the minimum and maximum elements in the array
        int min_val = *min_element(a, a + n);
        int max_val = *max_element(a, a + n);
        
        // The cost is the difference between the maximum and minimum values
        cout << max_val - min_val << endl;
    }

    return 0;
}
