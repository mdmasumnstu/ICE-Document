#include <iostream>
#include <iomanip> // For std::setprecision
using namespace std;

int main() 
{
    string name;
    getline(cin,name);

    double a,b,c,total;
    cin>>a>>b;

    c= (b*15)/100;
    total= a+c;
    printf("TOTAL = R$ %.2f\n",total);

    return 0;
}
