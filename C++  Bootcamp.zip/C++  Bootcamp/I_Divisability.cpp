#include <iostream>
using namespace std;

int main()
 {
    long long A, B,C,i,sum=0;
    cin >> A >> B>>C;

    if(A<B)
    {
        for(i=A;i<=B;i++)
        {
        if(i%C==0)
        {
            sum= sum+i;
        }
         }
    }

    if(A>B)
    {
        for(i=B;i<=A;i++)
        {
        if(i%C==0)
        {
            sum= sum+i;
        }
         }
    }

    cout<<sum<<endl;
    return 0;
}
