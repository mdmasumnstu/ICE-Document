#include <iostream>
#include <unordered_set> // Use unordered_set for faster distinct element checking
using namespace std;

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n; // Read n first

        // Use vectors for dynamic array sizes
        int a[n], b[n], c[n];

        // Read array a
        for (int i = 0; i < n; i++) {
            cin >> a[i];
        }

        // Read array b
        for (int i = 0; i < n; i++) {
            cin >> b[i];
        }

        // Compute array c
        for (int i = 0; i < n; i++) {
            c[i] = a[i] + b[i];
        }

        // Use an unordered_set to store distinct elements
        unordered_set<int> distinctElements;
        for (int i = 0; i < n; i++) {
            distinctElements.insert(c[i]);
            // Early exit if we already have 3 distinct elements
            if (distinctElements.size() >= 3) {
                break;
            }
        }

        // Check if there are at least three distinct elements
        if (distinctElements.size() >= 3) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
    return 0;
}