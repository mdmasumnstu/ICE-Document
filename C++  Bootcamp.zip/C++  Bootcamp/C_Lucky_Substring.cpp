#include <iostream>
#include <cstring>
using namespace std;

int main() {
    string s;
    cin >> s;

    int len = s.length();
    int four = 0, seven = 0;

    for (int i = 0; i < len; i++) 
    {
        if (s[i] == '4') 
        {
            four++;
        } 
        else if (s[i] == '7') 
        {
            seven++;
        }
    }

    if((four==0) && (seven==0))
    {
        cout<<"-1"<<endl;
    }
    
    else if((four>=seven)!=0)
    {
        cout<<"4";
    }
    
    else if((four<seven)!=0)
    {
        cout<<"7"<<endl;
    }

     
}
