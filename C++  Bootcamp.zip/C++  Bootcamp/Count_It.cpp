#include<iostream>
using namespace std;
int main()
{
    string s;
    getline(cin,s);

    int n= s.length();
    int i,cap=0,smp=0,space=0;

    for(i=0;i<n;i++)
    {
        if(s[i]>='a' && s[i]<='z')
        {
            smp++;
        }

        if(s[i]>='A' && s[i]<='Z')
        {
            cap++;
        }
        else if(s[i]==' ')
        {
            space++;
        }
    }
    cout<<"Capital - "<<cap<<endl;
    cout<<"Small - "<<smp<<endl;
    cout<<"Spaces - "<<space<<endl;
}