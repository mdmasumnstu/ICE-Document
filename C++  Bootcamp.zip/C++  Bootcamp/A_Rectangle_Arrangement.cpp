#include <iostream>
#include <algorithm>
using namespace std;

int main()
 {  
    int t;  
    cin >> t;

    while (t--) 
    {
        int n;
        cin >> n; 

        int max_width = 0, max_height = 0;

        for (int i = 0; i < n; i++)
         {
            int width, height;
            cin >> width >> height;

            max_width = max(max_width, width);
            max_height = max(max_height, height);
        }
        int perimeter = 2*(max_width + max_height);
        cout <<perimeter<< endl;
    }
}
