#include<iostream>
using namespace std;
int main()
{
 int a,b,m;
 cin>>a>>b;

 m=a*b;
 cout<<m<<endl;

}