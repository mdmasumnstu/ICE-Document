#include <iostream>
#include <string>

using namespace std;

int main() {
    int t;
    cin >> t;

    while (t--) {
        string s;
        cin >> s;
        int q;
        cin >> q;

        int n = s.size();
        int ones = 0, zeros = 0;
        for (int i = 0; i < 4; i++) {
            if (s[i] == '1') ones++;
            else zeros++;
        }

        bool found = ones == 2 && zeros == 2;

        while (q--) {
            int i, v;
            cin >> i >> v;
            i--;

            if (s[i] != v) {
                if (s[i] == '1') ones--;
                else zeros--;
                if (v == '1') ones++;
                else zeros++;

                if (i >= 3) {
                    if (s[i - 3] == '1') ones--;
                    else zeros--;
                }
            }

            s[i] = v;

            if (i >= 3) {
                if (ones == 2 && zeros == 2) {
                    found = true;
                } else {
                    found = false;
                }
            }

            cout << (found ? "YES" : "NO") << endl;
        }
    }

    return 0;
}