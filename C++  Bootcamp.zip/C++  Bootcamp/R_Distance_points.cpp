#include <iostream>
using namespace std;

int main()
 {
    long long float a,b,c,d;
    cin>>a>>b>>c>>d;

    

    return 0;
}
