#include <iostream>
using namespace std;

int main() {
    int M1, M2, D;
    cin >> M1 >> M2 >> D;

    int result = (M1 * D) / M2;

    cout << result << endl;
    return 0;
}
