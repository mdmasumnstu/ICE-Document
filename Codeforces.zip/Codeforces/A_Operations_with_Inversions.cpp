using namespace std;
#include <iostream>
#include <vector>
#include <algorithm>

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        std::vector<int> arr(n);
        for (int i = 0; i < n; ++i) {
            cin >> arr[i];
        }

        long long inversion_count = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) {
                if (arr[i] > arr[j]) {
                    inversion_count++;
                }
            }
        }

        cout << inversion_count << endl;
    }
    return 0;
}