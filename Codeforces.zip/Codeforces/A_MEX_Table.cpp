#include<iostream>
using namespace std;
int main()
{
    int t,sum;
    cin>>t;
    while(t--)
    {
        int a,b;
        cin>>a>>b;


        sum= a+b;
        cout<<sum<<endl;
    }
}